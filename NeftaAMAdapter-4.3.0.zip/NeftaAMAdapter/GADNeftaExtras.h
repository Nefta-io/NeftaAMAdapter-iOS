#import <GoogleMobileAds/GoogleMobileAds.h>

@interface GADNeftaExtras : NSObject  <GADAdNetworkExtras>
@property(nonatomic) BOOL muteAudio;
@end
