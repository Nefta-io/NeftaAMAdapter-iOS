#import "GADNeftaExtras.h"

@implementation GADNeftaExtras

@end
