#import <GoogleMobileAds/GoogleMobileAds.h>

@interface NeftaExtras : NSObject  <GADAdNetworkExtras>
@property(nonatomic) BOOL muteAudio;
@end
